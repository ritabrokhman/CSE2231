import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Keaton, Massimo, Rita
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    /**
     * Test constructor when empty.
     */
    @Test
    public final void testNoArgumentConstructor() {
        //Declare variables.
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test constructor with integer zero.
     */
    @Test
    public final void testConstructorIntZero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test constructor with integer above zero.
     */
    @Test
    public final void testConstructorIntNonZero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(1);
        NaturalNumber nExpected = this.constructorRef(1);

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test constructor with non-empty string.
     */
    @Test
    public final void testConstructorNonEmptyString() {
        //Declare variables.
        NaturalNumber n = this.constructorTest("1");
        NaturalNumber nExpected = this.constructorRef("1");

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test constructor with NaturalNumber zero.
     */
    @Test
    public final void testConstructorNaturalNumberZero() {
        //Declare variables.
        NaturalNumber test = this.constructorRef(0);
        NaturalNumber n = this.constructorTest(test);
        NaturalNumber nExpected = this.constructorRef(test);

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test constructor with NaturalNumber non-zero.
     */
    @Test
    public final void testConstructorNaturalNumberNonZero() {
        //Declare variables.
        NaturalNumber test = this.constructorRef(1);
        NaturalNumber n = this.constructorTest(test);
        NaturalNumber nExpected = this.constructorRef(test);

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test multiplyBy10 on NaturalNumber zero.
     */
    @Test
    public final void testMultiplyBy10Zero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(1);

        //Run kernel method.
        n.multiplyBy10(1);

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test multiplyBy10 on NaturalNumber non-zero.
     */
    @Test
    public final void testMultiplyBy10NonZero() {
        //Declare variables.
        final int eleven = 11;
        NaturalNumber n = this.constructorTest(1);
        NaturalNumber nExpected = this.constructorRef(eleven);

        //Run kernel method.
        n.multiplyBy10(1);

        //Compare.
        assertEquals(n, nExpected);
    }

    /**
     * Test divideBy10 on NaturalNumber non-zero.
     */
    @Test
    public final void testDivideBy10LeavingZero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(1);
        int iExpected = 1;
        NaturalNumber nExpected = this.constructorRef(0);

        //Run kernel method.
        int i = n.divideBy10();

        //Compare.
        assertEquals(n, nExpected);
        assertEquals(i, iExpected);
    }

    /**
     * Test divideBy10 on NaturalNumber non-zero.
     */
    @Test
    public final void testDivideBy10LeavingNonZero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(11);
        int iExpected = 1;
        NaturalNumber nExpected = this.constructorRef(1);

        //Run kernel method.
        int i = n.divideBy10();

        //Compare.
        assertEquals(n, nExpected);
        assertEquals(i, iExpected);
    }

    /**
     * Test isZero on NaturalNumber zero.
     */
    @Test
    public final void testisZeroOnZero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);
        boolean bExpected = true;

        //Run kernel method.
        boolean b = n.isZero();

        //Compare.
        assertEquals(nExpected, n);
        assertEquals(b, bExpected);
    }

    /**
     * Test isZero on NaturalNumber non-zero.
     */
    @Test
    public final void testisZeroOnNonZero() {
        //Declare variables.
        NaturalNumber n = this.constructorTest(1);
        NaturalNumber nExpected = this.constructorRef(1);
        boolean bExpected = false;

        //Run kernel method.
        boolean b = n.isZero();

        //Compare.
        assertEquals(nExpected, n);
        assertEquals(b, bExpected);
    }

}
