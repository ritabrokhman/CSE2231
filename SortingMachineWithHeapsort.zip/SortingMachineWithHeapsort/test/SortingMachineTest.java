import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /*
     * Sample test cases.
     */

    /**
     * Test that the constructor works.
     */
    @Test
    public final void testConstructor() {
        //Declare variables.
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        //Compare
        assertEquals(mExpected, m);
    }

    /**
     * Test adding an item to an empty Sorting Machine.
     */
    @Test
    public final void testAddEmpty() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");

        //Run kernel method.
        m.add("green");

        //Compare
        assertEquals(mExpected, m);
    }

    /**
     * Test add on a Sorting Machine that already has entries.
     */
    @Test
    public final void testAddNonEmpty() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue");

        //Run kernel method.
        m.add("blue");

        //Compare.
        assertEquals(mExpected, m);
    }

    /**
     * Test changeToExtractionMode.
     */
    @Test
    public final void testChangeToExtractionMode() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "green");

        //Run kernel method.
        m.changeToExtractionMode();

        //Compare.
        assertEquals(mExpected, m);
    }

    /**
     * Test removeFirst leaving an empty Sorting Machine.
     */
    @Test
    public final void testRemoveFirstToEmpty() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        String sExpected = "green";

        //Run kernel method.
        String s = m.removeFirst();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(sExpected, s);
    }

    /**
     * Test removeFirst leaving a non-empty Sorting Machine.
     */
    @Test
    public final void testRemoveFirstToNonEmpty() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green", "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "red");

        String sExpected = "green";

        //Run kernel method.
        String s = m.removeFirst();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(sExpected, s);

    }

    /**
     * Test removeFirst leaving a non-empty Sorting Machine with more entries.
     */
    @Test
    public final void testRemoveFirstToNonEmpty2() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "blue",
                "green", "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "green", "red");

        String sExpected = "blue";

        //Run kernel method.
        String s = m.removeFirst();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(sExpected, s);

    }

    /**
     * Test isInInsertionMode when true.
     */
    @Test
    public final void testIsInInsertionModeTrue() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "red");
        boolean bExpected = true;

        //Run kernel method.
        boolean b = m.isInInsertionMode();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(bExpected, b);

    }

    /**
     * Test isInInsertionMode when false.
     */
    @Test
    public final void testIsInInsertionModeFalse() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "red");
        boolean bExpected = false;

        //Run kernel method.
        boolean b = m.isInInsertionMode();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(bExpected, b);

    }

    /**
     * Test order.
     */
    @Test
    public final void testOrder() {
        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "red");

        //Run kernel method.
        Comparator<String> o = m.order();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(ORDER, o);

    }

    /**
     * Test length with empty.
     */
    @Test
    public final void testSizeEmpty() {

        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        //Run kernel method.
        int i = m.size();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(0, i);

    }

    /**
     * Test length with non-empty.
     */
    @Test
    public final void testSizeNonEmpty() {

        //Declare variables.
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "red");

        //Run kernel method.
        int i = m.size();

        //Compare.
        assertEquals(mExpected, m);
        assertEquals(1, i);
        assertEquals(mExpected.size(), m.size());

    }

}
