import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

/**
 * Program to copy a text file into another file.
 *
 * @author Put your name here
 *
 */
public final class FilterFileStdJava {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private FilterFileStdJava() {
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments: input-file-name output-file-name
     */
    public static void main(String[] args) {

        BufferedReader input;
        PrintWriter output;
        BufferedReader strings;
        //Deal with opening files.
        try {
            input = new BufferedReader(new FileReader(args[0]));
            output = new PrintWriter(
                    new BufferedWriter(new FileWriter(args[1])));
            strings = new BufferedReader(new FileReader(args[2]));
        } catch (IOException e) {
            System.err.println("Failed to open file(s).");

            return;
        }
        Set<String> words = new HashSet<String>();
        try {
            String word = strings.readLine();

            while (word != null) {
                words.add(word);
                word = strings.readLine();
            }

        } catch (IOException e) {
            System.err.println("Failed to read from third file.");
        }

        //Try to read and write until done or error.
        try {
            String s = input.readLine();
            while (s != null) {
                for (String x : words) {
                    if (s.contains(x)) {
                        output.println(s);
                    }
                }
                s = input.readLine();
            }
        } catch (IOException e) {
            System.err.println("Failed to read or write to file(s).");
        }

        //Try to close files.
        try {
            input.close();
            output.close();
            strings.close();
        } catch (IOException e) {
            System.err.println("Failed to close file(s).");
        }

    }

}
