import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * A Java program that counts word occurrences in a given input file and outputs
 * an HTML document with a table of the words and counts listed in alphabetical
 * order.
 *
 * @author Rita Brokhman
 *
 */
public final class WordCounter {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private WordCounter() {
        // no code needed here
    }

    /**
     * Compare {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            // use toLowerCase to compare both capitalized and non capitalized
            return o1.toLowerCase().compareTo(o2.toLowerCase());
        }
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> charSet) {
        assert str != null : "Violations of: str is not null";
        assert charSet != null : "Violation of: strSet is not null";

        for (int i = 0; i < str.length(); i++) {
            if (!charSet.contains(str.charAt(i))) {
                charSet.add(str.charAt(i));
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String string = "";

        if (!separators.contains(text.charAt(position))) {
            for (int i = position; i < text.length(); i++) {
                if (!separators.contains(text.charAt(i))) {
                    string += text.charAt(i);
                } else {
                    i = i + text.length();
                }
            }
        } else {
            for (int i = position; i < text.length(); i++) {
                if (separators.contains(text.charAt(i))) {
                    string += text.charAt(i);
                } else {
                    i = i + text.length();
                }
            }
        }
        return string;
    }

    /**
     * Outputs the file output.html. The method should follow this format...
     *
     * <html> <head> <title> title of the page </title> </head> <body>
     * <h2>title</h2>
     * <hr>
     * <table>
     * <tbody>
     * <tr>
     * <td>Individual words</td>
     * <td>Number of Occurrences</td>
     * </tr>
     * </tbody>
     * </table>
     * </hr>
     * </body> </html>
     *
     * @param map
     *            map containing entries of <individual word, number of
     *            occurrences>
     * @param out
     *            output stream
     * @param heading
     *            file name
     * @param queue
     *            queue of individual words
     * @updates out.content
     * @requires out.is_open
     * @ensures out.content = #out.content * [the HTML tags]
     */
    private static void generateHTML(Map<String, Integer> map, SimpleWriter out,
            String heading, Queue<String> queue) {
        assert out.isOpen() : "Violation of: out.is_open";

        out.print("<html>\r\n" + "<head>\r\n" + "<title> " + heading
                + "</title>\r\n" + "\r\n" + "</head>\r\n" + "\r\n");

        out.print("<body>\r\n" + "<h2>" + heading + "</h2>\r\n" + "<hr>"
                + "\r\n");

        out.print("<table border= \"1\"> \r\n");
        out.print("<tbody>\r\n");

        out.print("<tr>\r\n");
        out.print("<th>" + "Individual Word" + "</th>\r\n");
        out.print("<th>" + "Number of Occurrences" + "</th>\r\n");
        out.print("</tr>\r\n");

        // Cycle through all of the words
        for (int i = 0; i < queue.length(); i++) {
            String individualWord = queue.dequeue();
            out.print("<tr>\r\n");

            // Each word is printed in one column
            out.print("<td>" + individualWord + "</td>\r\n");

            // Each occurrence is printed in one column
            out.print("<td>" + map.value(individualWord) + "</td>\r\n");
            out.print("</tr>\r\n");
        }

        out.print("</tbody>\r\n" + "</table>\r\n" + "</body>\r\n" + "</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // The program shall ask the user for the name of an
        // input file and for the name of an output file.
        // The input file can be an arbitrary text file.
        // No special requirements are imposed.

        out.print("Enter the name of an input file: ");
        String input = in.nextLine();
        SimpleReader inputReader = new SimpleReader1L(input);

        out.print("Enter the name of an output file: ");
        String output = in.nextLine();
        SimpleWriter outputReader = new SimpleWriter1L(output);

        // Puts separators into a Set to determine if a specific String is a word
        Set<Character> separators = new Set1L<>();
        generateElements(" \t, .-", separators);

        // Cycle through the input file and put all of the individual words into a Queue
        Queue<String> wordQueue = new Queue1L<>();
        while (!inputReader.atEOS()) {
            String line = inputReader.nextLine();
            int i = 0;
            while (i < line.length()) {
                boolean isNotSeparator = true;
                // Cycle through the length of the String from the input line and do not add
                // Queue if it is a separator
                for (int j = 0; j < nextWordOrSeparator(line, i, separators)
                        .length(); j++) {
                    if (separators
                            .contains(nextWordOrSeparator(line, i, separators)
                                    .charAt(j))) {
                        isNotSeparator = false;
                    }
                }
                // If the String/character is not a separator, add the word to the Queue
                if (isNotSeparator) {
                    wordQueue.enqueue(nextWordOrSeparator(line, i, separators));
                }

                i += nextWordOrSeparator(line, i, separators).length();
            }
        }

        // Sort the wordQueue to make sure it is in alphabetical order
        Comparator<String> comparator = new StringLT();
        wordQueue.sort(comparator);

        // Put all of the words from wordQueue into a new-ish Queue so
        // I don't lose words when I manipulate them
        Queue<String> restorationQueue = wordQueue.newInstance();
        for (int i = 0; i < wordQueue.length(); i++) {
            String newWord = wordQueue.dequeue();
            restorationQueue.enqueue(newWord);
            wordQueue.enqueue(newWord);
        }

        // Pair each word with the number of times it occurs into a map
        Map<String, Integer> wordMap = new Map1L<>();
        for (int i = 0; i < wordQueue.length(); i++) {
            String word = wordQueue.dequeue();
            if (wordMap.hasKey(word)) {
                int occurrence = wordMap.value(word);
                wordMap.replaceValue(word, occurrence + 1);
            } else {
                // This means the word only occurs once
                wordMap.add(word, 1);
            }
        }

        // Make a new and clean set with no duplicates and sort it
        // Take individual words from wordQueue and use
        Set<String> noDupes = new Set1L<>();

        for (String i : restorationQueue) {
            if (!noDupes.contains(i)) {
                noDupes.add(i);
            }
        }

        for (String i : noDupes) {
            wordQueue.enqueue(i);
        }
        wordQueue.sort(comparator);

        // The output shall be a single well-formed HTML file
        // displaying the name of the input file in a heading
        // followed by a table listing the words and their corresponding counts.
        // The words should appear in alphabetical order.
        String heading = "Words in alphabetical order found in the file: "
                + input;
        // Use the generateHTML method to display words counted
        generateHTML(wordMap, outputReader, heading, wordQueue);

        inputReader.close();
        out.close();
        in.close();
    }

}