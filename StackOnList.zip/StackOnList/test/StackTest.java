import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.stack.Stack;

/**
 * JUnit test fixture for {@code Stack<String>}'s constructor and kernel
 * methods.
 *
 * @author Rita Brokhman
 *
 */
public abstract class StackTest {

    /**
     * Invokes the appropriate {@code Stack} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new stack
     * @ensures constructorTest = <>
     */
    protected abstract Stack<String> constructorTest();

    /**
     * Invokes the appropriate {@code Stack} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new stack
     * @ensures constructorRef = <>
     */
    protected abstract Stack<String> constructorRef();

    /**
     *
     * Creates and returns a {@code Stack<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the stack
     * @return the constructed stack
     * @ensures createFromArgsTest = [entries in args]
     */
    private Stack<String> createFromArgsTest(String... args) {
        Stack<String> stack = this.constructorTest();
        for (String s : args) {
            stack.push(s);
        }
        stack.flip();
        return stack;
    }

    /**
     *
     * Creates and returns a {@code Stack<String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the entries for the stack
     * @return the constructed stack
     * @ensures createFromArgsRef = [entries in args]
     */
    private Stack<String> createFromArgsRef(String... args) {
        Stack<String> stack = this.constructorRef();
        for (String s : args) {
            stack.push(s);
        }
        stack.flip();
        return stack;
    }

    /**
     * Constructor Test.
     */
    @Test
    public final void testConstructor() {
        Stack<String> s = this.constructorTest();
        Stack<String> sExpected = this.constructorRef();

        assertEquals(sExpected, s);
    }

    /**
     * Push Test Empty.
     */
    @Test
    public final void testPush() {
        Stack<String> s = this.createFromArgsTest();
        Stack<String> sExpected = this.createFromArgsRef("12345");

        s.push("12345");

        assertEquals(sExpected, s);
    }

    /**
     * Push Test Non-Empty.
     */
    @Test
    public final void testPush1() {
        Stack<String> s = this.createFromArgsTest("54321");
        Stack<String> sExpected = this.createFromArgsRef("12345", "54321");

        s.push("12345");

        assertEquals(sExpected, s);
    }

    /**
     * Pop Test Empty.
     */
    @Test
    public final void testPop() {
        Stack<String> s = this.createFromArgsTest("12345");
        Stack<String> sExpected = this.createFromArgsRef();

        String pop = s.pop();

        assertEquals(sExpected, s);
        assertEquals("12345", pop);
    }

    /**
     * Pop Test Non-Empty.
     */
    @Test
    public final void testPop1() {
        Stack<String> s = this.createFromArgsTest("12345", "54321");
        Stack<String> sExpected = this.createFromArgsRef("54321");

        String pop = s.pop();

        assertEquals(sExpected, s);
        assertEquals("12345", pop);
    }

    /**
     * Length Test Non-Empty.
     */
    @Test
    public final void testLength() {
        Stack<String> s = this.createFromArgsTest("12345");

        int length = s.length();

        assertEquals(1, length);
    }

    /**
     * Length Test Empty.
     */
    @Test
    public final void testLength1() {
        Stack<String> s = this.createFromArgsTest();

        int length = s.length();

        assertEquals(0, length);
    }

}