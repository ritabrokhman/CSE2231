import java.io.Serializable;
import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue2;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;

/**
 * A program to create an html document with a table of all words in a file in
 * addition to the number of occurrences.
 *
 * @author Keaton Kinderdine, Massimo Adams, Rita Brokhman
 *
 */
public final class TagCloudGenerator {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private TagCloudGenerator() {
    }

    /**
     * A class to contain a comparator to be used for alphabetizing.
     *
     * @author Keaton Kinderdine, Massimo Adams, Rita Brokhman
     *
     */
    private static class StringAlph
            implements Comparator<String>, Serializable {

        @Override
        //Simply use compareToIgnoreCase method in comparator.
        public int compare(String o1, String o2) {
            return o1.compareToIgnoreCase(o2);
        }
    }

    /**
     * A class to contain a comparator to be used for sorting a map based of the
     * value.
     *
     * @author Keaton Kinderdine, Massimo Adams, Rita Brokhman
     *
     */
    private static class sortMapPair
            implements Comparator<Map.Pair<String, Integer>>, Serializable {

        @Override
        //Simply use compareTo method in comparator.
        public int compare(Map.Pair<String, Integer> o1,
                Map.Pair<String, Integer> o2) {
            return o2.value().compareTo(o1.value());
        }
    }

    /**
     * Makes a HTML heading the will include the file name and beginning of a
     * table.
     *
     * @param out
     *            the file to be written to
     * @param inputFile
     *            the input file name
     * @param n
     *            number of words to be included in tag cloud generation
     * @requires out.is_open and out is not null
     * @ensures A properly formatted HTML heading with the start of a table
     */
    private static void headingHTML(SimpleWriter out, String inputFile, int n) {
        assert out != null : "Violation of: output is not null";
        assert out.isOpen() : "Violation of: output.is_open";

        //heading of the html file
        out.println("<html>");
        out.println("<head>\n<title>Top " + n + " words in " + inputFile
                + "</title>");
        out.print(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/");
        out.print("assignments/projects/tag-cloud-generator/data/tagcloud.css");
        out.println("\" rel=\"stylesheet\" type=\"text/css\">");
        out.println(
                "<link href=\"tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Top " + n + " words in " + inputFile + "</h2>\n<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     * text[position, position + |nextWordOrSeparator|) and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     * entries(nextWordOrSeparator) intersection separators = {} and
     * (position + |nextWordOrSeparator| = |text| or
     * entries(text[position, position + |nextWordOrSeparator| + 1))
     * intersection separators /= {})
     * else
     * entries(nextWordOrSeparator) is subset of separators and
     * (position + |nextWordOrSeparator| = |text| or
     * entries(text[position, position + |nextWordOrSeparator| + 1))
     * is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";
        //Declare variables and add first character to string.
        int newPos = position;
        String returnString = "";
        char firstChar = text.charAt(newPos);
        returnString += firstChar;
        newPos++;
        if (newPos < text.length()) {
            //If branch works with words.
            if (!separators.contains(firstChar)) {
                char temp = text.charAt(newPos);
                //Loop adds characters as long as it isn't in separators.
                while (!separators.contains(temp) && newPos < text.length()) {
                    returnString += temp;
                    newPos++;
                    //Ensure position doesn't get read over length.
                    if (newPos < text.length()) {
                        temp = text.charAt(newPos);
                    }
                }
                //Else branch works with separators.
            } else {
                char temp = text.charAt(newPos);
                //Loop adds characters as long as it is in separators.
                while (separators.contains(temp) && newPos < text.length()) {
                    returnString += temp;
                    newPos++;
                    //Ensure position doesn't get read over length.
                    if (newPos < text.length()) {
                        temp = text.charAt(newPos);
                    }
                }
            }
        }
        //Return statement.
        return returnString.toLowerCase();
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    public static void generateElements(String str, Set<Character> charSet) {
        assert str != null : "Violation of: str is not null";
        assert charSet != null : "Violation of: charSet is not null";

        //Create set to hold elements.
        Set<Character> newSet = new Set1L<>();

        //Parse each character and add to a set.
        for (int i = 0; i < str.length(); i++) {
            char temp = str.charAt(i);
            if (!newSet.contains(temp)) {
                newSet.add(temp);
            }
        }

        //Update charSet with newSet value.
        charSet.transferFrom(newSet);
    }

    /**
     * Adds {@code str} to {@code strSet} if and only if it is not a repeat
     * word.
     *
     * @param strSet
     *            set to consider adding to
     * @param str
     *            string to consider adding
     * @updates strSet
     * @requires CONTAINS_NO_REPEAT_WORDS(strSet)
     * @ensures <pre>
     * a word will be only added to the set if it is not a repeat
     * </pre>
     */
    public static void addToSetAvoidingRepeatWords(Set<String> strSet,
            String str) {
        assert strSet != null : "Violation of: strSet is not null";
        assert str != null : "Violation of: str is not null";

        boolean isRepeat = false;
        //Makes a temporary set to transfer the words to make them easier to compare
        Set<String> temp = strSet.newInstance();
        temp.transferFrom(strSet);
        while (temp.size() > 0) {
            String x = temp.removeAny();
            //Checks to see if str is a repeat word
            if (x.compareTo(str) == 0) {
                isRepeat = true;
            }
            strSet.add(x);
        }
        //if str is not a repeat , it gets added to the set
        if (!isRepeat) {
            strSet.add(str);
        }
    }

    /**
     * Returns the set of all individual words read from {@code input}, except
     * that any word that is the same as another is not in the returned set.
     *
     * @param input
     *            source of strings, one per line
     * @return set of words read from {@code input}
     * @requires input.is_open
     * @ensures <pre>
     * input.is_open  and  input.content = <>  and
     * linesFromInput = [maximal set of words from #input.content such that
     *                   there are no repeat words]
     * </pre>
     */
    public static Set<String> wordsFromInput(SimpleReader input) {
        //Create set containing a list of separators.
        Set<Character> separators = new Set1L<>();
        String separatorString = " ,.?!-;:[]*_'";
        generateElements(separatorString, separators);

        //Set that will be returned
        Set<String> strSet = new Set1L<>();

        //Loops through the whole file
        while (!input.atEOS()) {
            String str = input.nextLine();
            int pos = 0;
            ///Loop through each line with nextWordOrSeparator.
            while (pos <= str.length() - 1) {
                String word = nextWordOrSeparator(str, pos, separators);
                pos += word.length();
                //Add to set if not already present.
                if (!separators.contains(word.charAt(0))
                        && !strSet.contains(word)) {
                    strSet.add(word);

                }
            }
        }
        return strSet;

    }

    /**
     * Returns the number of times the given word appears in the text.
     *
     * @param input
     *            source of strings, one per line
     * @param wordToBeCounted
     *            the word that will be counted
     * @return the number of times the word appears in the text
     * @requires input.is_open
     * @ensures <pre>
     * An accurate count of how many time the word appears in the text
     * </pre>
     */
    public static int countWord(SimpleReader input, String wordToBeCounted) {
        assert input != null : "Violation of: input is not null";
        assert input.isOpen() : "Violation of: input.is_open";

        int count = 0;
        //Create set containing a list of separators.
        Set<Character> separators = new Set1L<>();
        String separatorString = " ,.?!-;:[]*_'";
        generateElements(separatorString, separators);
        //Loops through the whole file
        while (!input.atEOS()) {
            String str = input.nextLine();
            int pos = 0;
            //Loop through each line with nextWordOrSeparator.
            while (pos <= str.length() - 1) {
                String word = nextWordOrSeparator(str, pos, separators);
                pos += word.length();
                //Add to count if the words match.
                if (word.equals(wordToBeCounted)) {
                    count++;
                }

            }

        }
        return count;
    }

    /**
     * Returns a map of the words with the number of times the word appears.
     *
     * @param fName
     *            input file name
     * @param words
     *            the (@code Queue<String>) that all words are in.
     * @requires words is not null
     * @return a map of the words with the number of times the word appears.
     * @ensures <pre>
     * A map of the words with an accurate count of the number of times the word appears.
     * </pre>
     */
    public static Map<String, Integer> wordWithCountMap(String fName,
            Set<String> words) {
        //Creates the word map
        Map<String, Integer> wordMap = new Map1L<String, Integer>();
        //Loops through the entire queue and adds word with its count
        while (words.size() > 0) {
            SimpleReader fileInput = new SimpleReader1L(fName);
            String word = words.removeAny();
            int count = countWord(fileInput, word);
            wordMap.add(word, count);
            fileInput.close();
        }
        return wordMap;
    }

    /**
     * Returns a map of the words with the number of times the word appears.
     *
     * @param map
     *            the (@code Map<String, Integer>) that all words and their
     *            counts are in.
     * @param sorter
     *            the (@code SortingMachine<Map.Pair<String, Integer>>) that
     *            will be used to sort the map.
     * @param n
     *            number of words to be included in tag cloud generation
     * @requires map is not null
     * @return the {@code Queue<String>} of all the keys in the map
     * @ensures <pre>
     * A map of the words with an accurate count of the number of times the word appears.
     * </pre>
     */
    public static Queue<String> sortMap(Map<String, Integer> map,
            SortingMachine<Map.Pair<String, Integer>> sorter, int n) {
        //loops through the entire map and puts the map pairs into machine
        while (map.size() > 0) {
            Map.Pair<String, Integer> pair = map.removeAny();
            sorter.add(pair);
        }
        sorter.changeToExtractionMode();
        //Makes a queue to put the keys in
        Queue<String> qKey = new Queue2<String>();
        //adds the  number of words to be included in tag cloud generation to map
        for (int i = 0; i < n; i++) {
            Map.Pair<String, Integer> pair = sorter.removeFirst();
            qKey.enqueue(pair.key());
            map.add(pair.key(), pair.value());
        }
        return qKey;
    }

    /**
     * Returns a alphabetized {@code Queue<String>}.
     *
     * @param q
     *            the {@code Queue<String>to be sorted. @ensures <pre>
     *              A sorted queue.
     * </pre>
     */
    public static void sortQ(Queue<String> q) {
        //Make the sorting machine
        SortingMachine<String> sorter = new SortingMachine1L<String>(
                new StringAlph());
        //Put the items into the sorting machine
        while (q.length() > 0) {
            sorter.add(q.dequeue());
        }
        sorter.changeToExtractionMode();
        //Put sorted items back into q
        while (sorter.size() > 0) {
            q.enqueue(sorter.removeFirst());
        }
    }

    /**
     * Prints the tag cloud.
     *
     * @clears cloudMap and q
     * @param output
     *            the file to be printed to.
     * @param q
     *            the alphabetized (@code Queue<String>) of keys.
     * @param cloudMap
     *            the (@code Map<String, Integer>) that all words and their
     *            counts are in.
     * @requires q is not null and cloudMap is not null
     * @ensures <pre>
     * a tag cloud
     * </pre>
     */
    public static void printTagCloud(SimpleWriter output, Queue<String> q,
            Map<String, Integer> cloudMap) {
        //Get the max num of words in map
        Map<String, Integer> temp = cloudMap.newInstance();
        temp.transferFrom(cloudMap);
        Map.Pair<String, Integer> pair = temp.removeAny();
        int maxWord = pair.value();
        int minWord = pair.value();
        cloudMap.add(pair.key(), pair.value());
        while (temp.size() > 0) {
            pair = temp.removeAny();
            //Get max word.
            if (maxWord < pair.value()) {
                maxWord = pair.value();
            }
            //Get min word.
            if (minWord > pair.value()) {
                minWord = pair.value();
            }
            //Add pair back into map.
            cloudMap.add(pair.key(), pair.value());
        }
        //Get slope to use in point slope formula
        final float maxFont = 48;
        final float minFont = 11;
        float m = (maxFont - minFont) / (maxWord - minWord);
        //loop through the q until empty
        while (q.length() > 0) {
            //Print the word with the correct font size
            String word = q.dequeue();
            Map.Pair<String, Integer> pair2 = cloudMap.remove(word);
            //Gets the font size
            float size = m * (pair2.value() - minWord) + minFont;
            int fontSize = (int) size;
            output.println("<span style=\"cursor:default\" class=\"f" + fontSize
                    + "\" title=\"count: " + pair2.value() + "\">" + pair2.key()
                    + "</span>");
        }

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        //Declare input and output streams.
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //Request the input file name.
        out.print("Input file name to have its words counted: ");
        String inputName = in.nextLine();
        SimpleReader fileInput = new SimpleReader1L(inputName);
        //Request the output destination.
        out.print("Input destination location of output: ");
        String location = in.nextLine();
        //Create new SimpleWriter to output to new html file.
        SimpleWriter output = new SimpleWriter1L(location);
        //Request number of words to be included in tag cloud generation
        out.print(
                "Input number of words to be included in tag cloud generation: ");
        int num = in.nextInteger();
        //Print all starting tags
        headingHTML(output, inputName, num);
        //Call method to enter all words into the queue.
        Set<String> words = wordsFromInput(fileInput);
        //get a map with wit the words and counts
        Map<String, Integer> countMap = wordWithCountMap(inputName, words);
        //Make a sorting machine to sort the map
        Comparator<Map.Pair<String, Integer>> compareMap = new sortMapPair();
        SortingMachine<Map.Pair<String, Integer>> sorter = new SortingMachine1L<Map.Pair<String, Integer>>(
                compareMap);
        //sorts the map
        Queue<String> q = sortMap(countMap, sorter, num);
        sortQ(q);
        //Print the cloud map
        printTagCloud(output, q, countMap);
        //Print closing tags.
        output.print("</p>\n" + "</div>\n" + "</body>\n" + "</html>\n");

        /*
         * Close input and output streams
         */
        fileInput.close();
        output.close();
        in.close();
        out.close();

    }

}
